package nro.models.map;
public class WayPoint {

    public short minX;

    public short minY;

    public short maxX;

    public short maxY;

    public boolean isEnter;

    public boolean isOffline;

    public String name;

    public int goMap;

    public short goX;

    public short goY;
}
